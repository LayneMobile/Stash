/**
 * Automatically generated file. DO NOT MODIFY
 */
package rxsubscriptions.components;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String APPLICATION_ID = "rxsubscriptions.components";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "";
  public static final int VERSION_CODE = 3;
  public static final String VERSION_NAME = "0.1.2";
}
